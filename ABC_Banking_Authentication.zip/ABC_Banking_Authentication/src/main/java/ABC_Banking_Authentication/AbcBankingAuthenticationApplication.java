package ABC_Banking_Authentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcBankingAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcBankingAuthenticationApplication.class, args);
	}

}
