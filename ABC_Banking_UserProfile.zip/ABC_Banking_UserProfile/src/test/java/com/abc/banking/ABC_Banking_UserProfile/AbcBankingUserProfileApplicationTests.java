package com.abc.banking.ABC_Banking_UserProfile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcBankingUserProfileApplicationTests {

	@Test
	void contextLoads() {
	}

}
