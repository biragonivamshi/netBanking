package com.abc.banking.ABC_Banking_Account;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcBankingAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
