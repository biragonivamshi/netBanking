package ABC_Banking_Authentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AbcBankingAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
