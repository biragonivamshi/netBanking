package com.abc.banking.ABC_Banking_UserProfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcBankingUserProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcBankingUserProfileApplication.class, args);
	}

}
